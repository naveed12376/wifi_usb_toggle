@echo off
netsh interface set interface "Wi-Fi" admin=disable
reg add HKLM\SYSTEM\CurrentControlSet\Services\USBSTOR /v Start /t REG_DWORD /d 4 /f